<?php 
$con= mysqli_connect("localhost","root","",'task1');
if ($con==FALSE) {
	echo "You are not connected";
	}
	else{
		echo "";
	}
	date_default_timezone_set("Asia/Kolkata");
 ?>