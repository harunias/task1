<?php
include 'dbcon.php';
$taskid = $_GET['taskid'];
$qryedit = mysqli_query($con, "DELETE FROM `tasks` WHERE `taskid`='$taskid'");
header('location:assignedbyme.php');
